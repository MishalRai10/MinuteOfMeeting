//components/CheckConnection.js
import React from "react";
import api from "../services/api.js";
const CheckConnection = ()=> {
    console.log(api);
    const handleBtn =()=>{
        api.checkConnect();
    };
    return(
        <div>
            <h2>Checking for Connection</h2>
            <button onClick={handleBtn}
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-700"
            >Check</button>
        </div>
    );
};
export default CheckConnection;