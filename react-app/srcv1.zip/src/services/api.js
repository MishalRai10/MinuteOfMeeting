// services/api.js
import axios from 'axios';

const API_BASE_URL = 'http://127.0.0.1:5000';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

const generateSummary = async (content) => {
  try {
    const response = await api.post('/api/summarize', { content });
    return response.data;
  } catch (error) {
    throw new Error('Failed to generate summary');
  }
};

const uploadFile = async (file) => {
  const formData = new FormData();
  formData.append('file', file);

  try {
    const response = await api.post('/api/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  } catch (error) {
    throw new Error('Failed to upload file');
  }
};

const checkConnect = async ()=> {
  try{
    const response = await api.get('api/check_connection');
    console.log(response.data);
  }
  catch(error){
    console.log('Failed to check Connection', error);
  }
};

export default { generateSummary, uploadFile, checkConnect };
