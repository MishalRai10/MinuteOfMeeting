import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Dashboard from './components/Dashboard';
import Navigation from './Navigation';
import CheckConnection from './components/CheckConnection';
import CustomerReviews from './components/CustomerReviews';
import Features from './components/Features';

function App() {
  return (
    <div>
      <Navigation />
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/check" element={<CheckConnection/>}/>
      </Routes>
      <Features/>
      <CustomerReviews/>
    </div>
  );
}

export default App;
