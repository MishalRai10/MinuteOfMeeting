import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Twitter, Youtube, Menu, X } from 'lucide-react';
import logo from './media/logo.jpg'; // Adjusted path to your logo file

function Navigation() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 w-full h-14 bg-[#003347] z-50">
      <div className="container mx-auto flex justify-between items-center h-full py-4 px-6">
        <Link to="/" className="w-12">
          <img src={logo} alt="nav logo" className="object-cover object-center" />
        </Link>
        <ul className="hidden lg:flex gap-8 text-white">
          <li>
            <Link to="/" className="hover:text-[#ff7b02] transition-colors text-lg font-semibold py-2 px-4 rounded-lg hover:bg-[#ff7b02]/20">
              Dashboard
            </Link>
          </li>
          <li>
            <Link to="/about" className="hover:text-[#ff7b02] transition-colors text-lg font-semibold py-2 px-4 rounded-lg hover:bg-[#ff7b02]/20">
              About
            </Link>
          </li>
          <li>
            <Link to="/check" className="hover:text-[#ff7b02] transition-colors text-lg font-semibold py-2 px-4 rounded-lg hover:bg-[#ff7b02]/20">
              Check
            </Link>
          </li>
          {/* Add more links as needed */}
        </ul>
        <ul className="hidden lg:flex gap-4">
          <li>
            <a href="https://instagram.com" target="_blank" rel="noreferrer" className="w-8 h-8 grid place-items-center text-[#003347] bg-gradient-to-b from-[#e5a55d] to-[#ff7b02] rounded-lg hover:shadow-lg">
              <Instagram size={24} color="#003347" />
            </a>
          </li>
          <li>
            <a href="https://twitter.com" target="_blank" rel="noreferrer" className="w-8 h-8 grid place-items-center text-[#003347] bg-gradient-to-b from-[#e5a55d] to-[#ff7b02] rounded-lg hover:shadow-lg">
              <Twitter size={24} color="#003347" />
            </a>
          </li>
          <li>
            <a href="https://youtube.com" target="_blank" rel="noreferrer" className="w-8 h-8 grid place-items-center text-[#003347] bg-gradient-to-b from-[#e5a55d] to-[#ff7b02] rounded-lg hover:shadow-lg">
              <Youtube size={24} color="#003347" />
            </a>
          </li>
        </ul>
        <button className="block lg:hidden text-3xl text-white" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>
      {isOpen && (
        <ul className="absolute top-[4rem] right-0 text-white flex-col w-48 shadow-lg lg:hidden">
          <li className="h-20 bg-[#003347] hover:bg-[#003347]/80 flex items-center px-6">
            <Link to="/" onClick={() => setIsOpen(false)} className="hover:text-[#ff7b02] transition-colors text-lg font-semibold">
              Dashboard
            </Link>
          </li>
          <li className="h-20 bg-[#003347] hover:bg-[#003347]/80 flex items-center px-6">
            <Link to="/about" onClick={() => setIsOpen(false)} className="hover:text-[#ff7b02] transition-colors text-lg font-semibold">
              About
            </Link>
          </li>
          <li className="h-20 bg-[#003347] hover:bg-[#003347]/80 flex items-center px-6">
            <Link to="/check" onClick={() => setIsOpen(false)} className="hover:text-[#ff7b02] transition-colors text-lg font-semibold">
              Check
            </Link>
          </li>
          {/* Add more links as needed */}
        </ul>
      )}
    </nav>
  );
}

export default Navigation;